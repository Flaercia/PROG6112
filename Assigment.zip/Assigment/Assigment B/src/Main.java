import java.util.Scanner;



public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        UseBook ub = new UseBook();

        int choice;



        do {

            System.out.println("===== LIBRARY MENU =====");

            System.out.println("1. Capture Book");

            System.out.println("2. Search Book");

            System.out.println("3. Update Book");

            System.out.println("4. Delete Book");

            System.out.println("5. Print Report");

            System.out.println("6. Exit");

            System.out.print("Enter choice: ");

            choice = input.nextInt();

            input.nextLine();



            switch (choice) {

                case 1 -> ub.captureBook();

                case 2 -> ub.searchBook();

                case 3 -> ub.updateBook();

                case 4 -> ub.deleteBook();

                case 5 -> ub.printReport();

                case 6 -> System.out.println("Exiting...");

                default -> System.out.println("Invalid choice.\n");

            }

        } while (choice != 6);

    }

}

