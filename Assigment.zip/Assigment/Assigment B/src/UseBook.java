import java.util.Scanner;



// Child class extends Book (inheritance) and implements iBook interface

public class UseBook extends Book implements IBook {

    private static Book[] books = new Book[100];

    private static int count = 0;

    private static Scanner input = new Scanner(System.in);



    // Default constructor calls parent default constructor

    public UseBook() {

        super();

    }



    @Override

    public void captureBook() {

        System.out.println("=== ADD NEW BOOK ===");

        System.out.print("Enter Book ID: ");

        String id = input.nextLine();

        System.out.print("Enter Title: ");

        String title = input.nextLine();

        System.out.print("Enter Author: ");

        String author = input.nextLine();



        // Store in array

        books[count] = new Book(id, title, author, true);

        count++;

        System.out.println("Book added successfully.\n");

    }



    @Override

    public void searchBook() {

        System.out.print("Enter Book ID to search: ");

        String id = input.nextLine();



        for (int i = 0; i < count; i++) {

            if (books[i].getBookId().equals(id)) {

                System.out.println("Book found: " + books[i].getTitle() + " by " + books[i].getAuthor());

                return;

            }

        }

        System.out.println("Book not found.\n");

    }



    @Override

    public void updateBook() {

        System.out.print("Enter Book ID to update: ");

        String id = input.nextLine();



        for (int i = 0; i < count; i++) {

            if (books[i].getBookId().equals(id)) {

                System.out.print("Enter new Title: ");

                books[i].setTitle(input.nextLine());

                System.out.print("Enter new Author: ");

                books[i].setAuthor(input.nextLine());

                System.out.println("Book updated successfully.\n");

                return;

            }

        }

        System.out.println("Book not found.\n");

    }



    @Override

    public void deleteBook() {

        System.out.print("Enter Book ID to delete: ");

        String id = input.nextLine();



        for (int i = 0; i < count; i++) {

            if (books[i].getBookId().equals(id)) {

                // Shift array elements left

                for (int j = i; j < count - 1; j++) {

                    books[j] = books[j + 1];

                }

                books[count - 1] = null;

                count--;

                System.out.println("Book deleted successfully.\n");

                return;

            }

        }

        System.out.println("Book not found.\n");

    }



    @Override

    public void printReport() {

        System.out.println("=== BOOK REPORT ===");

        for (int i = 0; i < count; i++) {

            System.out.println(

                    books[i].getBookId() + " - " + books[i].getTitle() +

                            " by " + books[i].getAuthor() +

                            " | Available: " + books[i].isAvailable()

            );

        }

        System.out.println();

    }

}




