public interface IBook {

    void captureBook();

    void searchBook();

    void updateBook();

    void deleteBook();

    void printReport();

}

