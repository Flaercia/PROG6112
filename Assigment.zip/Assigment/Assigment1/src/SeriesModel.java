public class SeriesModel {

    public String id;

    public String name;

    public String age;

    public String episodes;



    public SeriesModel(String id, String name, String age, String episodes) {

        this.id = id;

        this.name = name;

        this.age = age;

        this.episodes = episodes;

    }

}

