import static org.junit.jupiter.api.Assertions.*;

class UseSeriesTest {

    @org.junit.jupiter.api.Test
    void captureSeries() {
    }

    @org.junit.jupiter.api.Test
    void searchSeries() {
    }

    @org.junit.jupiter.api.Test
    void updateSeries() {
    }

    @org.junit.jupiter.api.Test
    void deleteSeries() {
    }

    @org.junit.jupiter.api.Test
    void seriesReport() {
    }

    @org.junit.jupiter.api.Test
    void exitSeriesApplication() {
    }
}