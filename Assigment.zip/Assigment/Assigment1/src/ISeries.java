public interface ISeries {

    void captureSeries();

    void searchSeries();

    void updateSeries();

    void deleteSeries();

    void seriesReport();

    void exitSeriesApplication();

}

