package SectionB;

import java.util.Scanner;

public class UseModule extends Module implements IModule {

    private Scanner sc = new Scanner(System.in);

    @Override
    public void captureModule() {
        // Prompt user to input module details
        System.out.println("\n=== Capture New Module ===");

        System.out.print("Module ID: ");
        String id = sc.nextLine();

        System.out.print("Module Name: ");
        String name = sc.nextLine();

        System.out.print("Lecturer: ");
        String lecturer = sc.nextLine();

        int credits;
        // Loop to validate credits input (1-10)
        while (true) {
            System.out.print("Credits (1-10): ");
            try {
                credits = Integer.parseInt(sc.nextLine());
                if (credits >= 1 && credits <= 10) break;
                else System.out.println("Invalid credits! Enter 1-10.");
            } catch (NumberFormatException e) {
                System.out.println("Enter numbers only!");
            }
        }

        // Add new module to module list
        moduleList.add(new ModuleModel(id, name, lecturer, credits));
        System.out.println("Module successfully added!");
    }

    @Override
    public void searchModule() {
        // Prompt user for Module ID to search
        System.out.print("\nEnter Module ID to search: ");
        String id = sc.nextLine();

        // Loop through module list to find the module
        for (ModuleModel m : moduleList) {
            if (m.getModuleId().equals(id)) {
                System.out.println("\n--- Module Found ---");
                System.out.println("ID: " + m.getModuleId());
                System.out.println("Module Name: " + m.getModuleName());
                System.out.println("Lecturer: " + m.getLecturer());
                System.out.println("Credits: " + m.getCredits());
                return;
            }
        }

        // If module is not found
        System.out.println("Module not found!");
    }

    @Override
    public void updateModule() {
        // Prompt user for Module ID to update
        System.out.print("\nEnter Module ID to update: ");
        String id = sc.nextLine();

        for (ModuleModel m : moduleList) {
            if (m.getModuleId().equals(id)) {
                // Update module details
                System.out.print("New Module Name: ");
                m.setModuleName(sc.nextLine());

                System.out.print("New Lecturer: ");
                m.setLecturer(sc.nextLine());

                int credits;
                // Validate new credits input
                while (true) {
                    System.out.print("New Credits (1-10): ");
                    try {
                        credits = Integer.parseInt(sc.nextLine());
                        if (credits >= 1 && credits <= 10) {
                            m.setCredits(credits);
                            break;
                        } else {
                            System.out.println("Invalid credits! Enter 1-10.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Enter numbers only!");
                    }
                }

                System.out.println("Module successfully updated!");
                return;
            }
        }

        // If module ID is not found
        System.out.println("Module not found!");
    }

    @Override
    public void deleteModule() {
        // Prompt user for Module ID to delete
        System.out.print("\nEnter Module ID to delete: ");
        String id = sc.nextLine();

        for (ModuleModel m : moduleList) {
            if (m.getModuleId().equals(id)) {
                // Ask for confirmation before deleting
                System.out.print("Confirm delete module " + id + "? (A to confirm): ");
                String confirm = sc.nextLine();
                if (confirm.equalsIgnoreCase("A")) {
                    moduleList.remove(m);
                    System.out.println("Module deleted successfully!");
                }
                return;
            }
        }

        // If module is not found
        System.out.println("Module not found!");
    }

    @Override
    public void printReport() {
        // Print all modules in the list
        if (moduleList.isEmpty()) {
            System.out.println("\nNo modules found!");
            return;
        }

        System.out.println("\n=== Module Report ===");
        int count = 1;
        for (ModuleModel m : moduleList) {
            System.out.println("\nModule " + count++);
            System.out.println("ID: " + m.getModuleId());
            System.out.println("Module Name: " + m.getModuleName());
            System.out.println("Lecturer: " + m.getLecturer());
            System.out.println("Credits: " + m.getCredits());
        }
    }

    @Override
    public void exitModuleApplication() {
        // Exit the program
        System.out.println("Exiting the application...");
        System.exit(0);
    }
}
