package SectionB;

import java.util.Scanner;

public class ModuleApp {
    public static void main(String[] args) {
        UseModule moduleApp = new UseModule();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== MODULE MANAGEMENT =====");
            System.out.println("Enter (1) to open the menu or any other key to exit:");

            String start = sc.nextLine();
            if (!start.equals("1")) break;

            // Display menu options
            System.out.println("1. Capture Module");
            System.out.println("2. Search Module");
            System.out.println("3. Update Module");
            System.out.println("4. Delete Module");
            System.out.println("5. Print Report");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            String choice = sc.nextLine();

            // Execute selected action
            switch (choice) {
                case "1" -> moduleApp.captureModule();
                case "2" -> moduleApp.searchModule();
                case "3" -> moduleApp.updateModule();
                case "4" -> moduleApp.deleteModule();
                case "5" -> moduleApp.printReport();
                case "6" -> moduleApp.exitModuleApplication();
                default -> System.out.println("Invalid choice! Try again.");
            }
        }
        sc.close();
    }
}