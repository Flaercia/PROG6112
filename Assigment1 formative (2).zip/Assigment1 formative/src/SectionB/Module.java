package SectionB;

import java.util.ArrayList;

public class Module {

    // ArrayList to store all modules
    protected ArrayList<ModuleModel> moduleList;

    // Constructor to initialize the module list
    public Module() {
        moduleList = new ArrayList<>();
    }
}