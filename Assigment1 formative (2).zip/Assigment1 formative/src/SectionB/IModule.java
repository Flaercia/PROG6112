package SectionB;

public interface IModule {

    void captureModule();
    void searchModule();
    void updateModule();
    void deleteModule();
    void printReport();
    void exitModuleApplication();
}