package SectionA;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

/**
 * Unit tests for UseSeries class
 */
class UseSeriesTest {

    /**
     * TestSearchSeries()
     * To supply the series id to the series searching method.
     * The test will determine that the correct series data has been returned
     */
    @Test
    void TestSearchSeries() {
        System.out.println("TestSearchSeries - Valid series ID");

        UseSeries seriesApp = new UseSeries();
        SeriesModel series = new SeriesModel("001", "Breaking Bad", "2-18", "62");
        seriesApp.seriesList.add(series);

        // Simulate search by ID
        SeriesModel found = null;
        for (SeriesModel s : seriesApp.seriesList) {
            if (s.id.equals("001")) {
                found = s;
                break;
            }
        }

        assertNotNull(found, "Series should be found for valid ID");
    }

    /**
     * TestSearchSeries_SeriesNotFound()
     * To supply an incorrect series id to the series searching method.
     * The test will determine that no series was found.
     */
    @Test
    void TestSearchSeries_SeriesNotFound() {
        System.out.println("TestSearchSeries_SeriesNotFound - Invalid series ID");

        UseSeries seriesApp = new UseSeries();
        SeriesModel series = new SeriesModel("001", "Breaking Bad", "18", "62");
        seriesApp.seriesList.add(series);

        SeriesModel found = null;
        for (SeriesModel s : seriesApp.seriesList) {
            if (s.id.equals("999")) {
                found = s;
                break;
            }
        }

        assertNull(found, "Series should not be found for invalid ID");
    }

    /**
     * TestUpdateSeries()
     * To supply the Series id to the update series method.
     * The test will determine that the series has been successfully updated.
     */
    @Test
    void TestUpdateSeries() {
        System.out.println("TestUpdateSeries - Update series");

        UseSeries seriesApp = new UseSeries();
        SeriesModel series = new SeriesModel("001", "Breaking Bad", "18", "62");
        seriesApp.seriesList.add(series);

        boolean updated = false;
        for (SeriesModel s : seriesApp.seriesList) {
            if (s.id.equals("001")) {
                s.name = "Breaking Good";
                s.age = "16+";
                updated = true;
                break;
            }
        }

        assertTrue(updated, "Series should be updated successfully");
    }

    /**
     * TestDeleteSeries()
     * To supply the series id to the delete series method.
     * The test will determine that the series has been successfully deleted.
     */
    @Test
    void TestDeleteSeries() {
        System.out.println("TestDeleteSeries - Delete series");

        UseSeries seriesApp = new UseSeries();
        SeriesModel series = new SeriesModel("001", "Breaking Bad", "18", "62");
        seriesApp.seriesList.add(series);

        boolean deleted = seriesApp.seriesList.removeIf(s -> s.id.equals("001"));

        assertTrue(deleted, "Series should be deleted successfully");
    }

    /**
     * TestDeleteSeries_SeriesNotFound()
     * To supply an incorrect series id to the delete series method.
     * The test will determine that the series has not been deleted.
     */
    @Test
    void TestDeleteSeries_SeriesNotFound() {
        System.out.println("TestDeleteSeries_SeriesNotFound - Delete invalid series ID");

        UseSeries seriesApp = new UseSeries();
        SeriesModel series = new SeriesModel("001", "Breaking Bad", "18", "62");
        seriesApp.seriesList.add(series);

        boolean deleted = seriesApp.seriesList.removeIf(s -> s.id.equals("999"));

        assertFalse(deleted, "Series should not be deleted for invalid ID");
    }

    /**
     * TestSeriesAgeRestriction_AgeValid()
     * To supply a valid series age restriction to the series age restriction method.
     * The test will determine that the series age restriction is valid.
     */
    @Test
    void TestSeriesAgeRestriction_AgeValid() {
        System.out.println("TestSeriesAgeRestriction_AgeValid - Valid age");

        String age = "12";

        boolean valid = false;
        try {
            int a = Integer.parseInt(age);
            valid = a >= 0;
        } catch (NumberFormatException e) {
            valid = false;
        }

        assertTrue(valid, "Age restriction should be valid");
    }

    /**
     * TestSeriesAgeRestriction_SeriesAgeInValid()
     * To supply an invalid series age restriction to the series age restriction method.
     * The test will determine that the series age is invalid.
     */
    @Test
    void TestSeriesAgeRestriction_SeriesAgeInValid() {
        System.out.println("TestSeriesAgeRestriction_SeriesAgeInValid - Invalid age");

        String age = "-3";

        boolean valid = false;
        try {
            int a = Integer.parseInt(age);
            valid = a >= 0;
        } catch (NumberFormatException e) {
            valid = false;
        }

        assertFalse(valid, "Age restriction should be invalid");
    }
}