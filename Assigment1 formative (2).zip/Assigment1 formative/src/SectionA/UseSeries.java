package SectionA;

import java.util.Scanner;

// Subclass that extends Series and implements ISeries
public class UseSeries extends Series implements ISeries {

    private final Scanner sc = new Scanner(System.in);

    @Override
    public void captureSeries() {
        System.out.println("\n=== Capture New Series ===");

        System.out.print("Series ID: ");
        String id = sc.nextLine();

        System.out.print("Series Name: ");
        String name = sc.nextLine();

        // Age input with validation (must be between 2 and 18)
        String age;
        while (true) {
            System.out.print("Age restriction (2-18): ");
            age = sc.nextLine();
            try {
                int ageNum = Integer.parseInt(age);
                if (ageNum >= 2 && ageNum <= 18) break;
                else System.out.println("Invalid age! Enter 2-18.");
            } catch (NumberFormatException e) {
                System.out.println("Enter numbers only!");
            }
        }

        System.out.print("Number of episodes: ");
        String episodes = sc.nextLine();

        // Add the new series to the list
        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("Series successfully added!");
    }

    @Override
    public void searchSeries() {
        System.out.print("\nEnter series ID to search: ");
        String id = sc.nextLine();

        // Search for a series by ID
        for (SeriesModel s : seriesList) {
            if (s.id.equals(id)) {
                System.out.println("\n--- Series Found ---");
                System.out.println("ID: " + s.id);
                System.out.println("Name: " + s.name);
                System.out.println("Age restriction: " + s.age);
                System.out.println("Episodes: " + s.episodes);
                return;
            }
        }

        System.out.println("Series not found!");
    }

    @Override
    public void updateSeries() {
        System.out.print("\nEnter series ID to update: ");
        String id = sc.nextLine();

        // Find and update the series
        for (SeriesModel s : seriesList) {
            if (s.id.equals(id)) {
                System.out.print("New name: ");
                s.name = sc.nextLine();

                // Validate new age restriction
                String age;
                while (true) {
                    System.out.print("New age restriction (2-18): ");
                    age = sc.nextLine();
                    try {
                        int ageNum = Integer.parseInt(age);
                        if (ageNum >= 2 && ageNum <= 18) {
                            s.age = age;
                            break;
                        } else {
                            System.out.println("Invalid age! Enter 2-18.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Enter numbers only!");
                    }
                }

                System.out.print("New number of episodes: ");
                s.episodes = sc.nextLine();

                System.out.println("Series successfully updated!");
                return;
            }
        }

        System.out.println("Series not found!");
    }

    @Override
    public void deleteSeries() {
        System.out.print("\nEnter series ID to delete: ");
        String id = sc.nextLine();

        // Find and delete the series after confirmation
        for (SeriesModel s : seriesList) {
            if (s.id.equals(id)) {
                System.out.print("Confirm delete series " + id + "? (y to confirm): ");
                String confirm = sc.nextLine();
                if (confirm.equalsIgnoreCase("y")) {
                    seriesList.remove(s);
                    System.out.println("Series deleted!");
                }
                return;
            }
        }

        System.out.println("Series not found!");
    }

    @Override
    public void seriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("\nNo series found!");
            return;
        }

        // Display all series details
        System.out.println("\n=== Series Report ===");
        int count = 1;
        for (SeriesModel s : seriesList) {
            System.out.println("\nSeries " + count++);
            System.out.println("ID: " + s.id);
            System.out.println("Name: " + s.name);
            System.out.println("Age restriction: " + s.age);
            System.out.println("Episodes: " + s.episodes);
        }
    }

    @Override
    public void exitSeriesApplication() {
        System.out.println("Exiting the application...");
        System.exit(0);
    }
}