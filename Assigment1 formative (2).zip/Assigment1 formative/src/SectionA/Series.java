package SectionA;

import java.util.ArrayList;

public class Series {

    protected ArrayList<SeriesModel> seriesList;

    public Series() {

        seriesList = new ArrayList<>();

    }

}