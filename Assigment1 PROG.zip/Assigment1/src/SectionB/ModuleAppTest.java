package SectionB;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class ModuleAppTest {



        @Test
        void captureModules() {
        }

        @Test
        void searchModules() {
        }

        @Test
        void updateModules() {
        }

        @Test
        void deleteModules() {
        }

        @Test
        void ModulesReport() {
        }

        @Test
        void exitModulesApplication() {
        }
    }