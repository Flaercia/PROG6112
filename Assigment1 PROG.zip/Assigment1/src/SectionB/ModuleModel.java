package SectionB;

public class ModuleModel {

    private String moduleId;
    private String moduleName;
    private String lecturer;
    private int credits;

    // Constructor to initialize module details
    public ModuleModel(String moduleId, String moduleName, String lecturer, int credits) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.lecturer = lecturer;
        this.credits = credits;
    }

    // Getters and Setters for encapsulation
    public String getModuleId() { return moduleId; }
    public void setModuleId(String moduleId) { this.moduleId = moduleId; }

    public String getModuleName() { return moduleName; }
    public void setModuleName(String moduleName) { this.moduleName = moduleName; }

    public String getLecturer() { return lecturer; }
    public void setLecturer(String lecturer) { this.lecturer = lecturer; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    @Override
    public String toString() {
        // Display module info
        return moduleId + " | " + moduleName + " | Lecturer: " + lecturer + " | Credits: " + credits;
    }
}
