package SectionA;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UseSeriesTest {

    @Test
    void captureSeries() {
    }

    @Test
    void searchSeries() {
    }

    @Test
    void updateSeries() {
    }

    @Test
    void deleteSeries() {
    }

    @Test
    void seriesReport() {
    }

    @Test
    void exitSeriesApplication() {
    }
}