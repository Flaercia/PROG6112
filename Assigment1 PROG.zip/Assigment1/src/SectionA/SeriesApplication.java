package SectionA;

import java.util.Scanner;

public class SeriesApplication {

    public static void main(String[] args) {

        UseSeries seriesApp = new UseSeries();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== LATEST SERIES - 2025 ===");
            System.out.println("Enter (1) to open the menu or any other key to exit:");

            String start = sc.nextLine();

            // Exit the loop if input is not "1"
            if (!start.equals("1")) break;

            // Main menu
            System.out.println("\nChoose an option:");
            System.out.println("(1) Capture new series");
            System.out.println("(2) Search for a series");
            System.out.println("(3) Update series age restriction");
            System.out.println("(4) Delete series");
            System.out.println("(5) Print Series report");
            System.out.println("(6) Exit Application");

            String choice = sc.nextLine();

            // Handle user selection
            switch (choice) {
                case "1": seriesApp.captureSeries(); break;
                case "2": seriesApp.searchSeries(); break;
                case "3": seriesApp.updateSeries(); break;
                case "4": seriesApp.deleteSeries(); break;
                case "5": seriesApp.seriesReport(); break;
                case "6": seriesApp.exitSeriesApplication(); break;
                default: System.out.println("Invalid option! Try again.");
            }
        }
        // Close the Scanner when done
        sc.close();

    }
}

