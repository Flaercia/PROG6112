//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String[] month = {"JAN", "FEB", "MAR"};
        String[] cities = {"JHB", "DBN", "CTN", "PE"};
        int highest[][] = {
                {128, 135, 139},
                {155, 129, 175},
                {129, 130, 185},
                {195, 155, 221}
                
        };
        System.out.println();
        System.out.println("****************************************");
        System.out.println("SPEEDING FINES REPORT");
        System.out.println("*****************************************");

        System.out.printf("%-20s", "");
        for (String months : month) {
            System.out.printf("%-10s", months);
        }
        System.out.println();


        for (int i = 0; i < month.length; i++) {
            System.out.printf("%-20s", "" + cities[i]);
            for (int j = 0; j < month.length; j++) {
                System.out.printf("%-10d",highest[i][j]);
            }
            System.out.println();
        }


        int total = 0;
        int max = highest[0][0];
        int min = highest[0][0];

        for (int i = 0; i < month.length; i++) {
            for (int j = 0; j < month.length; j++) {
                int value = highest [i][j];
                total += value;
                if (value > max) max = value;
                if (value < min) min = value;
                System.out.println();
            }


            System.out.println("*********************************************");
            System.out.println("SPEEDING FINES REPORT ");
            System.out.println("*********************************************");

            System.out.printf("%-20s%d\n", "MAX : SPEEDING", max);
            System.out.printf("%-20s%d\n", "MIN :SPEEDING", min);

            }


        }



    }


