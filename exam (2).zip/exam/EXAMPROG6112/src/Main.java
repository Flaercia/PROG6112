//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // 2D array that stores the product sales data (year × quarter)
        int[][] sales = {
                {300, 150, 700}, // Sales for Year 1
                {250, 200, 600}  // Sales for Year 2
        };

        int total = 0;           // Variable to store the total sales
        int count = 0;           // Counter to keep track of the number of values
        int max = sales[0][0];   // Initialize maximum sale with the first element
        int min = sales[0][0];   // Initialize minimum sale with the first element

        // Loop through both years and all quarters
        for (int i = 0; i < sales.length; i++) {            // Outer loop for years
            for (int j = 0; j < sales[i].length; j++) {     // Inner loop for quarters
                int value = sales[i][j];                    // Get the current sales value
                total += value;                             // Add to total sales
                count++;                                    // Increase the number of entries

                // Check for maximum and minimum sales
                if (value > max) max = value;
                if (value < min) min = value;
            }
        }

        // Calculate the average sales value
        double average = (double) total / count;

        // Display the final sales report
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("----------------------------");
        System.out.println("Total sales: " + total);
        System.out.println("Average sales: " + Math.round( average)); // Round to nearest integer
        System.out.println("Maximum sale: " + max);
        System.out.println("Minimum sale: " + min);
    }
}