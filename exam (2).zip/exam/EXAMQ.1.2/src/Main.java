//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // 2D array that stores the product sales data (year × quarter)
        int[][] sales = {
                {300, 150, 700}, // Year 1
                {250, 200, 600}  // Year 2
        };

        // Create an object of ProductSales
        ProductSales ps = new ProductSales();

        // Generate and display the report
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("Total sales: " + ps.TotalSales(sales));
        System.out.println("Average sales: " + Math.round(ps.AverageSales(sales)));
        System.out.println("Maximum sale: " + ps.MaxSale(sales));
        System.out.println("Minimum sale: " + ps.MinSale(sales));
    }
}