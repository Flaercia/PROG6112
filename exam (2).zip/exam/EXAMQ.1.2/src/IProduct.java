public interface IProduct {
    int TotalSales(int[][] sales);
    double AverageSales(int[][] sales);
    int MaxSale(int[][] sales);
    int MinSale(int[][] sales);
}