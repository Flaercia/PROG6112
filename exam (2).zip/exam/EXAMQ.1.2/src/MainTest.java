import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        int[][] sales = {
                {300, 150, 700},
                {250, 200, 600}
        };
        ProductSales ps = new ProductSales();
        int total = ps.TotalSales(sales);
        assertEquals(2200, total, "The total sales should be 2200");
    }

    @Test
    public void AverageSales_ReturnsAverageProductSales() {
        int[][] sales = {
                {300, 150, 700},
                {250, 200, 600}
        };
        ProductSales ps = new ProductSales();
        double average = ps.AverageSales(sales);
        // we use a delta because it is a double
        assertEquals(366.67, average, 0.01, "The average should be approximately 366.67");
    }
}