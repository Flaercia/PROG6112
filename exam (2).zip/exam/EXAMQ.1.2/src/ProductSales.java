public class ProductSales implements IProduct {

    // This method calculates the total amount of all sales in the 2D array.
    // It loops through every year and every quarter, adding up all values.
    @Override
    public int TotalSales(int[][] sales) {
        int total = 0; // Variable that stores the accumulated total
        for (int i = 0; i < sales.length; i++) { // Loop through each year
            for (int j = 0; j < sales[i].length; j++) { // Loop through each quarter of the year
                total += sales[i][j]; // Add each sales value to the total
            }
        }
        return total; // Return the final total amount
    }

    // This method calculates the average sales value.
    // It uses the total sales divided by the total number of sales records.
    @Override
    public double AverageSales(int[][] sales) {
        int total = TotalSales(sales); // Reuse the TotalSales method to get the total amount
        int count = 0; // Counter for the number of sales entries
        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length; // Add the number of quarters for each year
        }
        return (double) total / count; // Return the average as a decimal value
    }

    // This method finds the highest (maximum) sales value in the 2D array.
    // It compares each sales value and keeps track of the largest one.
    @Override
    public int MaxSale(int[][] sales) {
        int max = sales[0][0]; // Start by assuming the first element is the maximum
        for (int i = 0; i < sales.length; i++) { // Loop through each year
            for (int j = 0; j < sales[i].length; j++) { // Loop through each quarter
                if (sales[i][j] > max) // If the current value is greater than the stored max
                    max = sales[i][j]; // Update the max with the current value
            }
        }
        return max; // Return the highest sales value found
    }

    // This method finds the smallest (minimum) sales value in the 2D array.
    // It works similarly to MaxSale but looks for the lowest number instead.
    @Override
    public int MinSale(int[][] sales) {
        int min = sales[0][0]; // Start by assuming the first element is the minimum
        for (int i = 0; i < sales.length; i++) { // Loop through each year
            for (int j = 0; j < sales[i].length; j++) { // Loop through each quarter
                if (sales[i][j] < min) // If the current value is smaller than the stored min
                    min = sales[i][j]; // Update the min with the current value
            }
        }
        return min; // Return the lowest sales value found
    }
}
