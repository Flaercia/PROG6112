public class ProductSales implements IProductSales {



    private final int[][] productSales;

    private final int SALES_LIMIT = 500;



    public ProductSales(int[][] productSales) {

        if (productSales == null || productSales.length == 0) {

            throw new IllegalArgumentException("productSales must not be null or empty");

        }

        this.productSales = productSales;

    }



    @Override

    public int[][] getProductSales() {

        return productSales;

    }



    @Override

    public int getTotalSales() {

        int total = 0;

        for (int[] year : productSales) {

            for (int sale : year) {

                total += sale;

            }

        }

        return total;

    }



    @Override

    public int getSalesOverLimit() {

        int count = 0;

        for (int[] year : productSales) {

            for (int sale : year) {

                if (sale > SALES_LIMIT) count++;

            }

        }

        return count;

    }



    @Override

    public int getSalesUnderLimit() {

        int count = 0;

        for (int[] year : productSales) {

            for (int sale : year) {

                if (sale <= SALES_LIMIT) count++;

            }

        }

        return count;

    }



    @Override

    public int getProductsProcessed() {

        // number of years processed

        return productSales.length;

    }



    @Override

    public double getAverageSales() {

        int totalItems = 0;

        for (int[] year : productSales) totalItems += year.length;

        if (totalItems == 0) return 0;

        return (double) getTotalSales() / totalItems;

    }

}

