import javax.swing.*;

import java.awt.*;

import java.io.FileWriter;

import java.io.IOException;



public class Main extends JFrame {



    private JTextArea txtDisplay;

    private JLabel lblYearsProcessed;



    // sample sales data (same as enunciado)

    private final int[][] productSales = {

            {300, 150, 700}, // year 1

            {250, 200, 600}  // year 2

    };



    // file name requested by enunciado (sample used data.txt)

    private final String OUTPUT_FILE = "data.txt";



    public Main() {

        super("Product Sales Application");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(420, 340);

        setLayout(new BorderLayout(8, 8));

        setLocationRelativeTo(null);



        // MENU

        JMenuBar menuBar = new JMenuBar();



        JMenu fileMenu = new JMenu("File");

        JMenuItem exitItem = new JMenuItem("Exit");

        fileMenu.add(exitItem);



        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem loadItem = new JMenuItem("Load Product Data");

        JMenuItem saveItem = new JMenuItem("Save Product Data");

        JMenuItem clearItem = new JMenuItem("Clear");



        toolsMenu.add(loadItem);

        toolsMenu.add(saveItem);

        toolsMenu.add(clearItem);



        menuBar.add(fileMenu);

        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);



        // BUTTON PANEL

        JPanel panelButtons = new JPanel(new GridLayout(2, 1, 8, 8));

        panelButtons.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnLoad = new JButton("Load Product Data");

        JButton btnSave = new JButton("Save Product Data");

        panelButtons.add(btnLoad);

        panelButtons.add(btnSave);

        add(panelButtons, BorderLayout.NORTH);



        // TEXT AREA

        txtDisplay = new JTextArea(8, 30);

        txtDisplay.setEditable(false);

        txtDisplay.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scroll = new JScrollPane(txtDisplay);

        add(scroll, BorderLayout.CENTER);



        // LABEL

        lblYearsProcessed = new JLabel("Years Processed: 0");

        lblYearsProcessed.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));

        add(lblYearsProcessed, BorderLayout.SOUTH);



        // ACTIONS (buttons)

        btnLoad.addActionListener(e -> calculateSalesData());

        btnSave.addActionListener(e -> saveDataToFile());



        // ACTIONS (menu items)

        exitItem.addActionListener(e -> System.exit(0));

        loadItem.addActionListener(e -> calculateSalesData());

        saveItem.addActionListener(e -> saveDataToFile());

        clearItem.addActionListener(e -> clearData());



        setVisible(true);

    }



    private void calculateSalesData() {

        ProductSales ps = new ProductSales(productSales);



        int totalSales = ps.getTotalSales();

        double avg = ps.getAverageSales();

        int roundedAvg = (int) Math.round(avg);

        int over = ps.getSalesOverLimit();

        int under = ps.getSalesUnderLimit();

        int years = ps.getProductsProcessed();



        StringBuilder sb = new StringBuilder();

        sb.append("Total Sales: ").append(totalSales).append("\n");

        sb.append("Average Sales: ").append(roundedAvg).append("\n");

        sb.append("Sales over limit: ").append(over).append("\n");

        sb.append("Sales under limit: ").append(under);



        txtDisplay.setText(sb.toString());

        lblYearsProcessed.setText("Years Processed: " + years);

    }



    private void saveDataToFile() {

        // If nothing has been loaded yet, prompt user or call calculate first

        if (txtDisplay.getText().trim().isEmpty()) {

            int option = JOptionPane.showConfirmDialog(this,

                    "No data displayed. Do you want to load product data and save it?",

                    "Save confirmation",

                    JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {

                calculateSalesData();

            } else {

                return;

            }

        }



        try (FileWriter writer = new FileWriter(OUTPUT_FILE)) {

            writer.write("DATA LOG\n");

            writer.write("****************************\n");

            writer.write(txtDisplay.getText() + "\n");

            writer.write("****************************\n");

            writer.write(lblYearsProcessed.getText() + "\n");

            JOptionPane.showMessageDialog(this, "Product data saved to " + OUTPUT_FILE);

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage(),

                    "Save error", JOptionPane.ERROR_MESSAGE);

        }

    }




    private void clearData() {

        txtDisplay.setText("");

        lblYearsProcessed.setText("Years Processed: 0");

    }



    public static void main(String[] args) {

        SwingUtilities.invokeLater(Main::new);

    }

}


