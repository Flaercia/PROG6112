public interface IProductSales {

    int[][] getProductSales();
    int getTotalSales();
    int getSalesOverLimit();
    int getSalesUnderLimit();
    int getProductsProcessed();
    double getAverageSales();
}